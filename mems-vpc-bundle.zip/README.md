# MEMS VPC Probe-Card Research Bundle

Self-contained bundle: a Claude Code **skill** plus a runnable **Python POC** for
MEMS VPC (vertical probe card) material / coating / ceramic guide-plate research
with EVT → DVT → PVT → MP closed-loop automation.

## Contents

```
.
├── .claude/skills/mems-vpc-research/   # Claude Code skill (project-scoped)
│   ├── SKILL.md
│   └── assets/
│       ├── research-doc-outline.md
│       └── poc-checklist.md
├── docs/research/mems-vpc-probe.md     # Controlling research design doc
├── mems_poc/                           # Runnable POC
│   ├── requirements.txt
│   ├── mems_vpc/                       # library code
│   ├── tests/                          # 26 pytest tests
│   └── examples/run_mems_flow.py       # end-to-end CLI demo
└── .gitignore
```

## Install (drop into an existing repo)

```bash
unzip mems-vpc-bundle.zip -d /path/to/your/repo/
cd /path/to/your/repo
```

The `.claude/skills/mems-vpc-research/` directory is a **project-scoped** Claude
Code skill — Claude Code will pick it up automatically when run in this repo.
To make it user-scoped (available across all your projects) instead, move it:

```bash
mv .claude/skills/mems-vpc-research ~/.claude/skills/
```

## Run the POC

```bash
cd mems_poc
pip install -r requirements.txt
python -m pytest tests/ -q          # 26 tests, ~1 s
python -m examples.run_mems_flow    # end-to-end demo
```

Expected demo output (last lines):

```
[EVT] decision=PASS evaluated=20 passing=3 promoted=[...]
[DVT] decision=PASS evaluated=3 passing=3 promoted=[...]
[PVT] decision=HOLD evaluated=3 passing=0 promoted=[]
    - Cpk(CRES)=11.93 (target 1.33)
    - mean yield=88.43%
```

(PVT HOLD on yield is intentional — it demonstrates the closed-loop catching a
real bottleneck. Tighten the `ProbeSpec` in the example to push past PVT.)

## Use the skill

In Claude Code, simply describe the task in natural language, e.g.:

> 我想做一個 MEMS VPC 探針卡的探針合金 + 鍍層 + 陶瓷導板研究，含 DVT EVT PVT MP 閉環自動化

The skill triggers on these intents (zh + en) and walks Claude through:
1. Clarifying scope via `AskUserQuestion`
2. Writing the research design doc per the 11-section outline
3. Scaffolding the POC mirroring `mems_poc/`
4. Preserving the non-obvious invariants (lot-indexed RNG, combo-id with
   drilling method, std-clamp in Cpk, Sobol power-of-2, feature standardisation)
5. Running tests + demo
6. Committing and opening a draft PR
7. Optionally subscribing to PR activity

See `.claude/skills/mems-vpc-research/SKILL.md` for the full workflow and
`assets/poc-checklist.md` for the per-module responsibility list.

## Architecture summary

Three research axes × four lifecycle stages:

| Axis | Reference catalog (in `mems_vpc/catalog.py`) |
|------|----------------------------------------------|
| R1 probe alloy | NiCo-20, NiMn-3, PdCo-15, BeCu-C17200, MP35N |
| R2 coating | Rh-tip-on-Au, Ru-tip, PdCo-thick, Au-soft, DLC-experimental |
| R3 ceramic | Al2O3 / ZrO2 / AlN / Si3N4 / MACOR × {laser-IR, laser-UV-fs, ultrasonic, micro-drill} |

Closed loop: `Spec → DOE/BO → VirtualLab → MeasurementRecord → Constraints +
StageGate → promote / HOLD / FAIL → next batch`.

## License

Treat this bundle as starter code; no warranty. Replace `VirtualLab` with a real
lab adapter (same `measure(combo, spec, stage, n_lots, lot_idx)` signature) when
wiring to actual fixtures.
